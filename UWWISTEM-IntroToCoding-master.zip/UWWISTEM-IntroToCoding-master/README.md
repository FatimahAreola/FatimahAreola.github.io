# WISTEM Intro To Coding Workshop 2017
An into to coding workshop run by UWaterloo's Women in STEM

Come learn the basics of web development and get to make your own personal website in the process!
We are starting from absolute scratch **(No Experiance necessary)**

## What we are covering
0. Basics of what a webpage looks like
1. What an element is
2. How to make your elements look pretty with CSS
3. Hosting your website using github pages

### If you liked this workshop and want to learn more:
- [Learn HTML on CodeCademy](https://www.codecademy.com/learn/learn-html)
- [Learn CSS on CodeCademy](https://www.codecademy.com/learn/learn-css)
- [Learn Flexbox using this cheatsheet](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)

### If you want to learn even more:
- Check out ReactJS and Bootstrap. Its a really great way to get deeper into web development
- Check out some courses on [udemy](https://www.udemy.com/the-web-developer-bootcamp/)

### [Don't forget to check us out on Facebook!](https://www.facebook.com/UWWiSTEM/)
